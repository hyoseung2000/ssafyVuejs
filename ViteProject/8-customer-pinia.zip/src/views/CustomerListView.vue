<script setup>
// import { ref } from "vue";
// import { selectAll } from "@/api/customer";
import { useCustomerStore } from "@/store/customer";
import { storeToRefs } from "pinia";

const store = useCustomerStore();
const { getCustomers: customers } = storeToRefs(store); //store 안의 데이터 리턴해주는 getter
const { allCustomers } = store; //비동기 요청하는 score 안의 action

// const customers = ref([]);

getAll();

function getAll() {
  allCustomers();
}

// function getAll() {
//   selectAll(
//     ({ data }) => {
//       customerList.value = data;
//       // console.log(data);
//     }, //success callback
//     (error) => {
//       console.log(error);
//     } //failure callback
//   );
// }

function search() {
  alert("주소로 회원을 검색합니다!");
  // let searchList = [];
  // customerList.value.forEach((c) => {
  //   if (c.address == address.value) {
  //     searchList.push(c);
  //   }
  // });

  // customerList.value = searchList;
  // clearText();
}

// find() vs filter()
// find: 조건 만족 첫번째 요소 반환 (단건 조회)
// filter: 조건 만족 새로운 배열 만들어서 반환 (여러건 조회)
</script>

<template>
  <div class="container">
    <h2>사용자 목록</h2>
    <table class="table text-center">
      <thead>
        <tr>
          <th class="text-center">번호</th>
          <th class="text-center">이름</th>
          <!-- <th class="text-center">주소</th> -->
        </tr>
      </thead>
      <tbody id="tb">
        <tr v-for="customer in customers" :key="customer.num">
          <td>{{ customer.num }}</td>
          <td>
            <RouterLink :to="{ name: 'detail', params: { num: customer.num } }">{{
              customer.name
            }}</RouterLink>
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style>
.container {
  margin-top: 1.5rem;
}
@media (min-width: 1024px) {
  .about {
    min-height: 100vh;
    display: flex;
    align-items: center;
  }
}
</style>
